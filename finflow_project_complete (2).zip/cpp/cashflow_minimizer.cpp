
//* Compile: g++ -o cashflow_minimizer cashflow_minimizer.cpp
 //* Run:     ./cashflow_minimizer

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <tuple>
#include <map>
#include <algorithm>
#include <sstream>
#include <iomanip>
#include <cmath>

using namespace std;



struct Transaction {
    string from;
    string to;
    double amount;
};

struct Person {
    string name;
    double netBalance; 
};



double roundTo2(double val) {
    return round(val * 100.0) / 100.0;
}

 //Greedy Cash Flow Minimization 

vector<Transaction> minimizeCashFlow(vector<Person>& people) {
    vector<Transaction> result;

    while (true) {
        int maxDebtor = -1;
        int maxCreditor = -1;
        double maxDebt = 0.0;
        double maxCredit = 0.0;

        for (int i = 0; i < (int)people.size(); i++) {
            double bal = roundTo2(people[i].netBalance);
            if (bal < -0.01 && bal < maxDebt) {
                maxDebt = bal;
                maxDebtor = i;
            }
            if (bal > 0.01 && bal > maxCredit) {
                maxCredit = bal;
                maxCreditor = i;
            }
        }

        if (maxDebtor == -1 || maxCreditor == -1) break;

        double settle = min(-people[maxDebtor].netBalance,
                             people[maxCreditor].netBalance);
        settle = roundTo2(settle);

        people[maxDebtor].netBalance  = roundTo2(people[maxDebtor].netBalance  + settle);
        people[maxCreditor].netBalance = roundTo2(people[maxCreditor].netBalance - settle);

        result.push_back({people[maxDebtor].name, people[maxCreditor].name, settle});
    }

    return result;
}

//  Main 

int main() {
    ifstream inFile("cash_input.txt");
    if (!inFile.is_open()) {
        ofstream errFile("cashflow_output.txt");
        errFile << "ERROR|Could not open cash_input.txt\n";
        return 1;
    }

    int n;
    inFile >> n;
    inFile.ignore();

    if (n <= 0 || n > 100) {
        ofstream errFile("cashflow_output.txt");
        errFile << "ERROR|Invalid number of people (must be 1-100)\n";
        return 1;
    }

    vector<string> names(n);
    map<string, int> nameIndex;
    for (int i = 0; i < n; i++) {
        getline(inFile, names[i]);
        while (!names[i].empty() && (names[i].front() == ' ' || names[i].front() == '\r'))
            names[i].erase(names[i].begin());
        while (!names[i].empty() && (names[i].back() == ' ' || names[i].back() == '\r'))
            names[i].pop_back();
        nameIndex[names[i]] = i;
    }

    int t;
    inFile >> t;
    inFile.ignore();

    vector<Person> people(n);
    for (int i = 0; i < n; i++) {
        people[i].name = names[i];
        people[i].netBalance = 0.0;
    }

    vector<tuple<string,string,double>> rawTxns;
    int validTxns = 0;

    for (int i = 0; i < t; i++) {
        string line;
        getline(inFile, line);
        while (!line.empty() && (line.front() == ' ' || line.front() == '\r'))
            line.erase(line.begin());
        while (!line.empty() && (line.back() == ' ' || line.back() == '\r'))
            line.pop_back();
        if (line.empty()) continue;

        istringstream ss(line);
        string payer, payee;
        double amount;
        if (!(ss >> payer >> payee >> amount)) continue;
        if (amount <= 0) continue;
        if (nameIndex.find(payer) == nameIndex.end() ||
            nameIndex.find(payee) == nameIndex.end()) continue;

        int pi = nameIndex[payer];
        int qi = nameIndex[payee];
        people[pi].netBalance += amount;
        people[qi].netBalance -= amount;
        rawTxns.push_back({payer, payee, amount});
        validTxns++;
    }

    inFile.close();

    vector<Transaction> optimized = minimizeCashFlow(people);

    ofstream outFile("cashflow_output.txt");
    outFile << fixed << setprecision(2);
    outFile << "SUCCESS\n";
    outFile << "PEOPLE|" << n << "\n";
    outFile << "ORIGINAL|" << validTxns << "\n";
    outFile << "OPTIMIZED|" << optimized.size() << "\n";

for (auto& txn : rawTxns) {
    auto a = get<0>(txn);
    auto b = get<1>(txn);
    auto amt = get<2>(txn);

    outFile << "RAW|" << a << "|" << b << "|" << amt << "\n";
}
    for (auto& txn : optimized) {
        outFile << "TXN|" << txn.from << "|" << txn.to << "|" << txn.amount << "\n";
    }

    outFile.close();
    cout << "Done. Optimized " << validTxns << " -> " << optimized.size() << " transactions.\n";
    return 0;
}
