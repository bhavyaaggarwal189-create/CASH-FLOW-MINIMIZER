import json
from django.db import models


class Expense(models.Model):
    expense_id = models.CharField(max_length=30, unique=True)
    date = models.CharField(max_length=20)
    cat = models.CharField(max_length=50)
    desc = models.CharField(max_length=300)
    amount = models.FloatField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-date', '-created_at']

    def to_dict(self):
        return {
            'id': self.expense_id,
            'date': self.date,
            'cat': self.cat,
            'desc': self.desc,
            'amount': self.amount,
        }


class Budget(models.Model):
    amount = models.FloatField(default=0)


class EMI(models.Model):
    emi_id = models.CharField(max_length=30, unique=True)
    name = models.CharField(max_length=200)
    total = models.FloatField()
    monthly = models.FloatField()
    remaining = models.FloatField()
    next_date = models.CharField(max_length=20)
    paid_count = models.IntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    def to_dict(self):
        return {
            'id': self.emi_id,
            'name': self.name,
            'total': self.total,
            'monthly': self.monthly,
            'remaining': self.remaining,
            'nextDate': self.next_date,
            'paidCount': self.paid_count,
        }


class CashFlowSession(models.Model):
    session_id = models.CharField(max_length=30, unique=True)
    label = models.CharField(max_length=200, default='Session')
    people_json = models.TextField(default='[]')
    transactions_json = models.TextField(default='[]')
    created_at = models.CharField(max_length=30)

    @property
    def people(self):
        return json.loads(self.people_json)

    @people.setter
    def people(self, value):
        self.people_json = json.dumps(value)

    @property
    def transactions(self):
        return json.loads(self.transactions_json)

    @transactions.setter
    def transactions(self, value):
        self.transactions_json = json.dumps(value)

    def to_dict(self):
        return {
            'id': self.session_id,
            'label': self.label,
            'people': self.people,
            'transactions': self.transactions,
            'createdAt': self.created_at,
        }
