import io
import json
from datetime import datetime
from collections import defaultdict

from django.http import HttpResponse
from rest_framework.decorators import api_view
from rest_framework.response import Response

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
)

from .models import Expense, Budget, EMI, CashFlowSession


# ─────────────────────────────────────────────
#  EXPENSES
# ─────────────────────────────────────────────

@api_view(['GET', 'POST'])
def expenses(request):
    if request.method == 'GET':
        data = [e.to_dict() for e in Expense.objects.all().order_by('date')]
        return Response(data)

    body = request.data
    if not body.get('id') or not body.get('amount'):
        return Response({'error': 'Missing fields'}, status=400)

    Expense.objects.filter(expense_id=str(body['id'])).delete()
    Expense.objects.create(
        expense_id=str(body['id']),
        date=body.get('date', ''),
        cat=body.get('cat', 'Other'),
        desc=body.get('desc', 'Expense'),
        amount=float(body['amount']),
    )
    return Response({'ok': True}, status=201)


@api_view(['DELETE'])
def delete_expense(request, expense_id):
    deleted, _ = Expense.objects.filter(expense_id=str(expense_id)).delete()
    if deleted:
        return Response({'ok': True})
    return Response({'error': 'Not found'}, status=404)


@api_view(['DELETE'])
def clear_expenses(request):
    Expense.objects.all().delete()
    return Response({'ok': True})


# ─────────────────────────────────────────────
#  BUDGET
# ─────────────────────────────────────────────

@api_view(['GET', 'POST'])
def budget(request):
    if request.method == 'GET':
        b = Budget.objects.first()
        return Response({'amount': b.amount if b else 0})

    amount = float(request.data.get('amount', 0))
    Budget.objects.all().delete()
    if amount > 0:
        Budget.objects.create(amount=amount)
    return Response({'ok': True})


# ─────────────────────────────────────────────
#  EMIs
# ─────────────────────────────────────────────

@api_view(['GET', 'POST'])
def emis(request):
    if request.method == 'GET':
        return Response([e.to_dict() for e in EMI.objects.all()])

    body = request.data
    if not body.get('id') or not body.get('name'):
        return Response({'error': 'Missing fields'}, status=400)

    EMI.objects.filter(emi_id=str(body['id'])).delete()
    EMI.objects.create(
        emi_id=str(body['id']),
        name=body['name'],
        total=float(body['total']),
        monthly=float(body['monthly']),
        remaining=float(body.get('remaining', body['total'])),
        next_date=body.get('nextDate', ''),
        paid_count=int(body.get('paidCount', 0)),
    )
    return Response({'ok': True}, status=201)


@api_view(['DELETE'])
def delete_emi(request, emi_id):
    deleted, _ = EMI.objects.filter(emi_id=str(emi_id)).delete()
    if deleted:
        return Response({'ok': True})
    return Response({'error': 'Not found'}, status=404)


@api_view(['DELETE'])
def clear_emis(request):
    EMI.objects.all().delete()
    return Response({'ok': True})


# ─────────────────────────────────────────────
#  CASH FLOW MINIMIZER (Greedy algorithm)
# ─────────────────────────────────────────────

def _greedy_minimize(people, transactions):
    balance = {p: 0.0 for p in people}
    for t in transactions:
        balance[t['from']] = round(balance[t['from']] + t['amount'], 2)
        balance[t['to']] = round(balance[t['to']] - t['amount'], 2)

    result = []
    bal_list = [{'name': n, 'bal': b} for n, b in balance.items()]

    while True:
        max_debtor = max(bal_list, key=lambda x: -x['bal'] if x['bal'] < -0.01 else float('-inf'))
        max_creditor = max(bal_list, key=lambda x: x['bal'] if x['bal'] > 0.01 else float('-inf'))

        if max_debtor['bal'] >= -0.01 or max_creditor['bal'] <= 0.01:
            break

        settle = round(min(-max_debtor['bal'], max_creditor['bal']), 2)
        max_debtor['bal'] = round(max_debtor['bal'] + settle, 2)
        max_creditor['bal'] = round(max_creditor['bal'] - settle, 2)
        result.append({'from': max_debtor['name'], 'to': max_creditor['name'], 'amount': settle})

    return result, {item['name']: item['bal'] for item in bal_list}


@api_view(['POST'])
def optimize_cashflow(request):
    people = request.data.get('people', [])
    transactions = request.data.get('transactions', [])

    if len(people) < 2:
        return Response({'error': 'Need at least 2 people'}, status=400)

    optimized, balances = _greedy_minimize(people, transactions)
    return Response({
        'optimized': optimized,
        'balances': balances,
        'original_count': len(transactions),
        'optimized_count': len(optimized),
        'saved': len(transactions) - len(optimized),
    })


@api_view(['GET', 'POST'])
def cashflow_sessions(request):
    if request.method == 'GET':
        return Response([s.to_dict() for s in CashFlowSession.objects.all().order_by('-created_at')])

    body = request.data
    sid = str(body.get('id', int(datetime.now().timestamp() * 1000)))
    CashFlowSession.objects.filter(session_id=sid).delete()
    session = CashFlowSession(
        session_id=sid,
        label=body.get('label', 'Session'),
        created_at=datetime.now().isoformat(),
    )
    session.people = body.get('people', [])
    session.transactions = body.get('transactions', [])
    session.save()
    return Response({'ok': True, 'id': sid}, status=201)


@api_view(['DELETE'])
def delete_cashflow_session(request, session_id):
    CashFlowSession.objects.filter(session_id=str(session_id)).delete()
    return Response({'ok': True})


# ─────────────────────────────────────────────
#  FULL STATE SYNC
# ─────────────────────────────────────────────

@api_view(['GET'])
def full_state(request):
    b = Budget.objects.first()
    return Response({
        'expenses': [e.to_dict() for e in Expense.objects.all().order_by('date')],
        'budget': b.amount if b else 0,
        'emis': [e.to_dict() for e in EMI.objects.all()],
        'sessions': [s.to_dict() for s in CashFlowSession.objects.all().order_by('-created_at')],
    })


# ─────────────────────────────────────────────
#  ANALYTICS ENDPOINT
# ─────────────────────────────────────────────

@api_view(['GET'])
def analytics(request):
    """Returns aggregated analytics for the dashboard."""
    expenses_qs = Expense.objects.all()
    all_expenses = list(expenses_qs.values('date', 'cat', 'amount'))

    # Category totals
    cat_totals = defaultdict(float)
    monthly_totals = defaultdict(float)
    daily_totals = defaultdict(float)
    total_spent = 0.0

    for e in all_expenses:
        cat_totals[e['cat']] += e['amount']
        month_key = e['date'][:7] if e['date'] else 'Unknown'
        monthly_totals[month_key] += e['amount']
        daily_totals[e['date']] += e['amount']
        total_spent += e['amount']

    b = Budget.objects.first()
    budget_amt = b.amount if b else 0

    emi_total_monthly = sum(e.monthly for e in EMI.objects.all())
    emi_total_pending = sum(e.remaining for e in EMI.objects.all())

    return Response({
        'total_spent': round(total_spent, 2),
        'budget': budget_amt,
        'remaining': round(budget_amt - total_spent, 2),
        'category_totals': dict(cat_totals),
        'monthly_totals': dict(sorted(monthly_totals.items())),
        'daily_totals': dict(sorted(daily_totals.items())),
        'expense_count': len(all_expenses),
        'emi_monthly_outflow': round(emi_total_monthly, 2),
        'emi_pending': round(emi_total_pending, 2),
    })


# ─────────────────────────────────────────────
#  PDF EXPORT
# ─────────────────────────────────────────────

@api_view(['POST'])
def export_pdf(request):
    """Generate a professional financial report PDF."""
    data = request.data
    expenses_data = data.get('expenses', [])
    budget_amt = float(data.get('budget', 0))
    emis_data = data.get('emis', [])

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer, pagesize=A4,
        topMargin=20 * mm, bottomMargin=20 * mm,
        leftMargin=20 * mm, rightMargin=20 * mm,
    )

    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        'CustomTitle', parent=styles['Title'],
        fontSize=22, textColor=colors.HexColor('#1a1a2e'),
        spaceAfter=4 * mm,
    )
    heading_style = ParagraphStyle(
        'CustomHeading', parent=styles['Heading2'],
        fontSize=14, textColor=colors.HexColor('#16213e'),
        spaceBefore=8 * mm, spaceAfter=4 * mm,
    )
    body_style = ParagraphStyle(
        'CustomBody', parent=styles['Normal'],
        fontSize=10, textColor=colors.HexColor('#333333'),
        spaceAfter=2 * mm,
    )

    elements = []
    now = datetime.now()

    # Title
    elements.append(Paragraph('FinFlow — Financial Report', title_style))
    elements.append(Paragraph(
        f'Generated: {now.strftime("%B %d, %Y at %I:%M %p")}',
        body_style
    ))
    elements.append(HRFlowable(
        width="100%", thickness=1,
        color=colors.HexColor('#4ade80'), spaceAfter=6 * mm
    ))

    # Summary
    total_spent = sum(e.get('amount', 0) for e in expenses_data)
    remaining = budget_amt - total_spent
    emi_monthly = sum(e.get('monthly', 0) for e in emis_data)

    elements.append(Paragraph('Financial Summary', heading_style))
    summary_data = [
        ['Metric', 'Value'],
        ['Total Expenses', f'₹{total_spent:,.2f}'],
        ['Monthly Budget', f'₹{budget_amt:,.2f}'],
        ['Remaining', f'₹{remaining:,.2f}'],
        ['Budget Usage', f'{(total_spent / budget_amt * 100):.1f}%' if budget_amt > 0 else 'N/A'],
        ['Active EMIs', str(len(emis_data))],
        ['Monthly EMI Outflow', f'₹{emi_monthly:,.2f}'],
    ]
    t = Table(summary_data, colWidths=[80 * mm, 80 * mm])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1a1a2e')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('ALIGN', (1, 0), (1, -1), 'RIGHT'),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#e0e0e0')),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f8f8f8')]),
        ('TOPPADDING', (0, 0), (-1, -1), 6),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
    ]))
    elements.append(t)

    # Category breakdown
    if expenses_data:
        elements.append(Paragraph('Category Breakdown', heading_style))
        cat_totals = defaultdict(float)
        for e in expenses_data:
            cat_totals[e.get('cat', 'Other')] += e.get('amount', 0)

        cat_data = [['Category', 'Amount', '% of Total']]
        for cat, amt in sorted(cat_totals.items(), key=lambda x: -x[1]):
            pct = (amt / total_spent * 100) if total_spent > 0 else 0
            cat_data.append([cat, f'₹{amt:,.2f}', f'{pct:.1f}%'])

        t2 = Table(cat_data, colWidths=[60 * mm, 50 * mm, 50 * mm])
        t2.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#16213e')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('ALIGN', (1, 0), (-1, -1), 'RIGHT'),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#e0e0e0')),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f8f8f8')]),
            ('TOPPADDING', (0, 0), (-1, -1), 5),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
        ]))
        elements.append(t2)

    # Expense list
    if expenses_data:
        elements.append(Paragraph('All Expenses', heading_style))
        exp_table_data = [['Date', 'Category', 'Description', 'Amount']]
        for e in sorted(expenses_data, key=lambda x: x.get('date', ''), reverse=True):
            desc_text = (e.get('desc', '')[:40] + '...') if len(e.get('desc', '')) > 40 else e.get('desc', '')
            exp_table_data.append([
                e.get('date', ''),
                e.get('cat', ''),
                desc_text,
                f'₹{e.get("amount", 0):,.2f}',
            ])

        t3 = Table(exp_table_data, colWidths=[30 * mm, 30 * mm, 60 * mm, 40 * mm])
        t3.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#0f3460')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 8),
            ('ALIGN', (3, 0), (3, -1), 'RIGHT'),
            ('GRID', (0, 0), (-1, -1), 0.4, colors.HexColor('#e0e0e0')),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f8f8f8')]),
            ('TOPPADDING', (0, 0), (-1, -1), 4),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
        ]))
        elements.append(t3)

    # EMIs
    if emis_data:
        elements.append(Paragraph('EMI / Loan Details', heading_style))
        emi_table = [['Loan Name', 'Total', 'Monthly', 'Remaining', 'Status']]
        for e in emis_data:
            rem = e.get('remaining', 0)
            status = 'PAID OFF' if rem <= 0 else 'Active'
            emi_table.append([
                e.get('name', ''),
                f'₹{e.get("total", 0):,.2f}',
                f'₹{e.get("monthly", 0):,.2f}',
                f'₹{rem:,.2f}',
                status,
            ])

        t4 = Table(emi_table, colWidths=[35 * mm, 32 * mm, 32 * mm, 32 * mm, 25 * mm])
        t4.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#533483')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 8),
            ('ALIGN', (1, 0), (-1, -1), 'RIGHT'),
            ('GRID', (0, 0), (-1, -1), 0.4, colors.HexColor('#e0e0e0')),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f8f8f8')]),
            ('TOPPADDING', (0, 0), (-1, -1), 4),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
        ]))
        elements.append(t4)

    # Footer
    elements.append(Spacer(1, 10 * mm))
    elements.append(HRFlowable(
        width="100%", thickness=0.5,
        color=colors.HexColor('#cccccc'), spaceAfter=3 * mm
    ))
    elements.append(Paragraph(
        'Generated by FinFlow — DAA Finance Suite',
        ParagraphStyle('Footer', parent=styles['Normal'],
                       fontSize=8, textColor=colors.HexColor('#999999'),
                       alignment=1)
    ))

    doc.build(elements)
    buffer.seek(0)

    response = HttpResponse(buffer, content_type='application/pdf')
    filename = f'finflow_report_{now.strftime("%Y%m%d_%H%M")}.pdf'
    response['Content-Disposition'] = f'attachment; filename="{filename}"'
    response['Access-Control-Expose-Headers'] = 'Content-Disposition'
    return response
