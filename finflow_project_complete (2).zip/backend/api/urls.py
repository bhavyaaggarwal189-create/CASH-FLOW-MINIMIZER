from django.urls import path
from . import views

urlpatterns = [
    # Full state
    path('state/', views.full_state),

    # Expenses
    path('expenses/', views.expenses),
    path('expenses/clear/', views.clear_expenses),
    path('expenses/<str:expense_id>/', views.delete_expense),

    # Budget
    path('budget/', views.budget),

    # EMIs
    path('emis/', views.emis),
    path('emis/clear/', views.clear_emis),
    path('emis/<str:emi_id>/', views.delete_emi),

    # Cash Flow
    path('cashflow/optimize/', views.optimize_cashflow),
    path('cashflow/sessions/', views.cashflow_sessions),
    path('cashflow/sessions/<str:session_id>/', views.delete_cashflow_session),

    # Analytics
    path('analytics/', views.analytics),

    # PDF Export
    path('export/pdf/', views.export_pdf),
]
