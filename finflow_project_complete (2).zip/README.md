# FinFlow — DAA Finance Suite

A full-stack financial management dashboard combining **expense tracking**, **budget management**, **EMI/loan tracking**, and a **greedy cash flow minimization algorithm** (DAA module).

## Architecture

```
Frontend (HTML/CSS/JS)  ←→  Django REST API  ←→  SQLite Database
         ↓                        ↓
   localStorage (cache)     db.sqlite3 (persistent)
```

**Key design:** The frontend works offline using localStorage and syncs with the Django/SQLite backend when available. All features function in both modes.

## Quick Start

```bash
# 1. Install dependencies
cd backend
pip install -r requirements.txt

# 2. Start the backend (auto-creates SQLite DB)
bash start.sh

# 3. Open the dashboard
# Open frontend/finflow_dashboard.html in any browser
```

Or manually:
```bash
cd backend
python manage.py makemigrations api
python manage.py migrate
python manage.py runserver
# Then open frontend/finflow_dashboard.html
```

## Features

### Expense Tracker
- Add, delete, and categorize expenses (Food, Transport, Shopping, Health, etc.)
- Category-wise breakdown with progress bars and charts
- Bar chart and table views

### Budget Manager
- Set monthly budget with real-time tracking
- Health status indicators (color-coded warnings at 50%/80%/100%)
- Category vs budget breakdown table

### EMI Manager
- Track multiple loans/EMIs with payment schedules
- One-click EMI payment with auto-date advancement
- Progress tracking per loan with paid-off detection

### Cash Flow Minimizer (DAA Core)
- **Algorithm:** Greedy net-balance pairing — minimizes the number of transactions needed to settle debts among a group
- Add participants and inter-person transactions
- Runs via Django backend (Python) or JS fallback (offline)
- Downloadable input/output files
- Includes C++ implementation: `cpp/cashflow_minimizer.cpp`

### Data Management
- **PDF Export** — Professional financial report via ReportLab (requires backend)
- **JSON Export/Import** — Full data backup and restore
- **Reset** — Clear individual sections or full system reset
- Storage usage monitor

## Tech Stack

| Layer     | Technology                          |
|-----------|-------------------------------------|
| Frontend  | HTML5, CSS3, Vanilla JS, Chart.js   |
| Backend   | Django 4.2, Django REST Framework   |
| Database  | SQLite3 (local, zero-config)        |
| PDF Gen   | ReportLab                           |
| Algorithm | Greedy (Python + C++ + JS)          |

## API Endpoints

| Method | Path                         | Description              |
|--------|------------------------------|--------------------------|
| GET    | `/api/state/`                | Full state sync          |
| GET    | `/api/expenses/`             | List all expenses        |
| POST   | `/api/expenses/`             | Add/upsert expense       |
| DELETE | `/api/expenses/<id>/`        | Delete expense           |
| DELETE | `/api/expenses/clear/`       | Clear all expenses       |
| GET    | `/api/budget/`               | Get budget               |
| POST   | `/api/budget/`               | Set budget               |
| GET    | `/api/emis/`                 | List EMIs                |
| POST   | `/api/emis/`                 | Add/upsert EMI           |
| DELETE | `/api/emis/<id>/`            | Delete EMI               |
| DELETE | `/api/emis/clear/`           | Clear all EMIs           |
| POST   | `/api/cashflow/optimize/`    | Run greedy minimizer     |
| GET    | `/api/analytics/`            | Aggregated analytics     |
| POST   | `/api/export/pdf/`           | Generate PDF report      |

## Database

Uses **SQLite** — the database file (`db.sqlite3`) is created automatically on first run. No external database server needed.

**Models:**
- `Expense` — date, category, description, amount
- `Budget` — single budget record
- `EMI` — loan name, total, monthly payment, remaining balance, payment count
- `CashFlowSession` — saved cash flow optimization sessions

## Cash Flow Algorithm

The greedy algorithm works by:
1. Computing net balance for each participant
2. Sorting creditors and debtors
3. Repeatedly pairing the maximum creditor with the maximum debtor
4. Settling the minimum of their absolute balances

**Time Complexity:** O(n log n) where n = number of participants
**Space Complexity:** O(n)

Compile and run the C++ version:
```bash
cd cpp
g++ -std=c++17 -O2 -o cashflow_minimizer cashflow_minimizer.cpp
./cashflow_minimizer cash_input.txt cashflow_output.txt
```
