#!/bin/bash
# ═══════════════════════════════════════════════
#  FinFlow — Startup Script
#  Starts the Django backend (SQLite) and opens
#  the frontend dashboard in your browser.
# ═══════════════════════════════════════════════

set -e

echo ""
echo "╔═══════════════════════════════════════════╗"
echo "║        FinFlow — DAA Finance Suite        ║"
echo "║     Backend: Django + SQLite (local)      ║"
echo "╚═══════════════════════════════════════════╝"
echo ""

# Navigate to backend
cd "$(dirname "$0")/backend"

# Install dependencies if needed
if ! python3 -c "import django" 2>/dev/null; then
    echo "📦 Installing Python dependencies..."
    pip install -r requirements.txt
fi

# Run migrations (creates db.sqlite3 automatically)
echo "🗄️  Running database migrations..."
python3 manage.py makemigrations api --noinput 2>/dev/null || true
python3 manage.py migrate --noinput

echo ""
echo "✅ SQLite database ready: backend/db.sqlite3"
echo ""

# Start Django server
echo "🚀 Starting Django server on http://localhost:8000 ..."
echo "📊 Open frontend/finflow_dashboard.html in your browser"
echo ""
echo "   Press Ctrl+C to stop the server"
echo ""

python3 manage.py runserver 0.0.0.0:8000
